#include "Game.hpp"

int main(int argc, char const *argv[])
{
    Game game;
    game.start();

    return 0;
}
